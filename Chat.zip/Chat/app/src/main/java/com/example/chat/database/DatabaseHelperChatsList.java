package com.example.chat.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class DatabaseHelperChatsList extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "CHATS_APP_DATABASE";
    private static final String TABLE_CHATS = "CHATS_APP_DATABASE";

    private static final String COL_ID = "id";
    private static final String COL_NAME = "name";
    private static final String COL_NEW_MESSAGE = "new_message";
    private static final String COL_TIME = "time";


    public DatabaseHelperChatsList(final Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        SQLiteDatabase db = this.getWritableDatabase();
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_DATABASE = String.format("CREATE %s(id INTEGER PRIMARY KEY AUTOINCREMENT ,name TEXT ,new_message INTEGER, time TEXT)", DATABASE_NAME);
        db.execSQL(CREATE_DATABASE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_CHATS);
    }

    public boolean insertNewChat(String _name_, String _new_message_, String _time_){
        SQLiteDatabase db = this.getWritableDatabase();


        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put(COL_NAME,_name_);
            contentValues.put(COL_NEW_MESSAGE,_new_message_);
            contentValues.put(COL_TIME,_time_);

            long result = db.insert(TABLE_CHATS,null, contentValues);
            db.close();

            return result != -1;

        }catch (Exception e){
            Log.e("Error",e.toString());
            return false;
        }
    }

    public chatsList getAllChats(){
        SQLiteDatabase db = this.getWritableDatabase();

        @SuppressLint("Recycle")
        chatsList res = (chatsList) db.rawQuery("Select * from "  + TABLE_CHATS,null);
        return res;
    }

    public Integer deleteChat(String _id_){
        SQLiteDatabase db = this.getWritableDatabase();

        return db.delete(TABLE_CHATS, "id=?",new String[]{_id_});
    }
}
