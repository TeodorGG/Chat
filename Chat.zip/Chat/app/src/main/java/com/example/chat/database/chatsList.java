package com.example.chat.database;

public class chatsList {
    int _id;
    String _name;
    int _new_message;
    String _time;

    public chatsList(int _id, String _name, int _new_message, String _time) {
        this._id = _id;
        this._name = _name;
        this._new_message = _new_message;
        this._time = _time;
    }

    chatsList(){}

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String get_name() {
        return _name;
    }

    public void set_name(String _name) {
        this._name = _name;
    }

    public int get_new_message() {
        return _new_message;
    }

    public void set_new_message(int _new_message) {
        this._new_message = _new_message;
    }

    public String get_time() {
        return _time;
    }

    public void set_time(String _time) {
        this._time = _time;
    }
}
